import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import { Container, Row, Col, Card, Button } from "react-bootstrap";

function Home() {
  return (
    <div
      style={{
        minHeight: "100vh",
        background: `url("https://th.bing.com/th/id/R.06267fc47d3d0f5e6182da405650563b?rik=2EVHxqp%2bh%2foZYA&riu=http%3a%2f%2fwww.karmanews.it%2fwp-content%2fuploads%2f2014%2f02%2fnotes-music.jpg&ehk=X1IaJ%2bEh7%2bOCfw93lEuOYnqQS%2bWYxlBsn0vvpnvfWb8%3d&risl=&pid=ImgRaw&r=0") center/cover no-repeat`,
      }}
    >
      {/* Hero Section */}
      <header
        style={{
          background: "rgba(0,0,0,0.7)",
          color: "white",
          padding: "100px 0",
        }}
      >
        <Container>
          <Row className="justify-content-center text-center">
            <Col md={10}>
              <h1 className="display-3 fw-bold text-warning mb-4">
                🎶 Welcome to My Music Application
              </h1>
              <p className="lead fs-4 text-light mb-4">
                Discover, Listen, and Enjoy the world of music like never before.
              </p>
              <Button variant="warning" size="lg" className="px-5 fw-bold">
                Get Started
              </Button>
            </Col>
          </Row>
        </Container>
      </header>

      {/* Features Section */}
      <section className="py-5">
        <Container>
          <Row className="g-4">
            <Col md={4}>
              <Card className="h-100 border-0 shadow-lg rounded-4 text-center">
                <Card.Body>
                  <Card.Title className="fs-3">🎧 Discover</Card.Title>
                  <Card.Text className="text-muted">
                    Explore trending music genres and discover fresh artists that match your vibe.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card className="h-100 border-0 shadow-lg rounded-4 text-center">
                <Card.Body>
                  <Card.Title className="fs-3">🎼 Listen</Card.Title>
                  <Card.Text className="text-muted">
                    Stream high-quality songs and albums without interruptions.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
            <Col md={4}>
              <Card className="h-100 border-0 shadow-lg rounded-4 text-center">
                <Card.Body>
                  <Card.Title className="fs-3">🎉 Enjoy</Card.Title>
                  <Card.Text className="text-muted">
                    Create playlists, share with friends, and enjoy music anywhere, anytime.
                  </Card.Text>
                </Card.Body>
              </Card>
            </Col>
          </Row>
        </Container>
      </section>

      {/* Premium Section */}
      <section
        style={{
          background: "linear-gradient(135deg, #f8f9fa, #e9ecef)",
        }}
        className="py-5"
      >
        <Container>
          <Row className="text-center">
            <Col>
              <h2 className="fw-bold mb-3">🚀 Unlock Premium Features!</h2>
              <p className="mb-4 fs-5 text-muted">
                Get <strong className="text-success">unlimited streaming</strong> for just{" "}
                <strong>Rs.99</strong>. Elevate your music experience with premium.
              </p>
              <Button variant="success" size="lg" className="px-5 fw-bold shadow">
                Buy Now
              </Button>
            </Col>
          </Row>
        </Container>
      </section>

    </div>
  );
}

export default Home;
